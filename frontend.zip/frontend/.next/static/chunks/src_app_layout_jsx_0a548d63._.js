(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__1e6d3767._.css",
  "static/chunks/node_modules_next_dist_3d8feecb._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f5df3b96._.js",
  "static/chunks/src_app_login_token_token_module_4523ab9f.css"
],
    source: "dynamic"
});
